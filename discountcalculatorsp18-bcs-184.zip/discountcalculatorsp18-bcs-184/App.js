import { NavigationContainer } from '@react-navigation/native';
import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react';
import { Button, Keyboard, ScrollView, StyleSheet, Text, TextInput, View , TouchableOpacity} from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';



const DiscountCalculator=({navigation})=>{
  const [getText,setText]=useState();
  const [getDtext,setDtext]=useState();
  const [items,setitems]=useState([{ key:'',Price1: '',Price2:'',FinalPrice:''}]);
  const add=()=>{
    setitems([...items,{key:Math.random().toString(),Price1:getText,Price2:getDtext,FinalPrice:(getText)-Math.round((getText)*(getDtext)/100)}])
  }
  
  
  
  
  
  return (
    <View style={styles.DCcontainer}>
      
      <View style={styles.TextInputContainer}>
      <TextInput style={styles.TextInput} placeholder="enter original price" onChangeText={text=>setText(text)}></TextInput>
      <TextInput style={styles.TextInput}placeholder="enter discount in numeric" onChangeText={text=>setDtext(text)}></TextInput>
      <View style={styles.btn1}>
      <Button title="Calculate & save" onPress={add} disabled={!getText&&!getDtext}> </Button></View>
      
      <View styles={styles.btn2}>
      <Button title="View History" style={styles.Buttonstyle}  onPress={()=>navigation.navigate('History',{items})}  ></Button>
      </View>
      </View>
      <View>
        <Text style={styles.result}>
          Final Price After Discount {items.FinalPrice}
        
        </Text>
      </View>
      <View>
        <Text>
          
        
        </Text>
      </View>
      <ScrollView>
        {items.map(item=>(<Text>{item.FinalPrice}</Text>))}
        
            
      
        
      </ScrollView>

      
    </View>
  );
  }
  const History=({navigation , route})=>{
    const[getList,setList]=useState(route.params.items)
    const displayitem=(item,index)=>{
    return(
      <View style={styles.ScrollViewItem}><Text style={styles.ScrollViewText}>{index}:  {item.Price1}  {item.Price2}  {item.FinalPrice}</Text>
       
       <Button title="remove" onPress={()=>deleteitem(item.key)}></Button>
       
       </View>
       
      
      
      
      
    )

  }
  const deleteitem=(itemkey)=>{
    setList(list=>getList.filter(item=>item.key!=itemkey))

  }
  const deleteHistory=(itemkey)=>{
    setList(list=>getList.filter(item=>itemkey==='y'))
  }
  return(
      <View style={styles.container}>
          <ScrollView style={styles.ScrollViewStyle}>
                    
              {getList.map(displayitem)}
                         
          </ScrollView>
          <Button title="clear History" onPress={()=>deleteHistory(getList.key)}></Button>
         
          
      </View>
  );
}



const Stack = createStackNavigator()
 export default function App() {
  
  return (
    <NavigationContainer>
      <Stack.Navigator
      screeOptions={{headerTitleAlign:"center",headerTintColor:'black',headerStyle:{backgroundColor:'skin'}
}}
      >
        <Stack.Screen name="Home" component={DiscountCalculator} options={{title:'Discount Calculator',headerTitleAlign:"center",headerTintColor:'black',headerStyle:{backgroundColor:'skin'}
        
        }}></Stack.Screen>
        <Stack.Screen name="History" component={History}></Stack.Screen>
        

      </Stack.Navigator>
      
    </NavigationContainer>
    

    
      
      
    
  );
  }

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    paddingTop:50
   
  },
  DCcontainer:{
      alignItems:'center',
      

  },

  
  TextInput:{
    borderColor:'orange',
    borderBottomWidth:2,
    width:'60%',
    padding:8,
    marginBottom:10
    

  },
  TextInputContainer:{
    
    justifyContent:'center',
    alignItems:'center'
    

    
  },
  Buttonstyle:{
    marginBottom:10
    
  },
  ScrollViewStyle:{
    padding:20,
    width:'100%'

  },
  ScrollViewItem:{
    
    justifyContent:'center',
    backgroundColor:'orange',
    width:'80%',
    alignSelf:'center',
    padding:10,
    margin:10,
    borderRadius:20,
    flexDirection:'row',
    justifyContent:'space-between'
    
    
  },
  ScrollViewText:
  {
    justifyContent:'center',
    alignItems:'center'
  },
  
  result:{
    color:'black',
    paddingTop:20 ,
    flexDirection:'row',
    fontSize:20 },
    btn1:{
      justifyContent:'center',

      padding:20
    },
    btn2:{
      justifyContent:'center'


    }
  

  
});
